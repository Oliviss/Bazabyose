# BAZABYOSE backend for Render

## Render setup
- Create a NEW Web Service from the existing `Oliviss/Bazabyose` repository.
- Root Directory: `backend`
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Add the environment variables listed in `.env.example` in Render.
- `FIREBASE_SERVICE_ACCOUNT_BASE64` must contain the base64-encoded Firebase service-account JSON for project `bazabyose`.
- Add Cloudinary API Key and API Secret from Cloudinary Dashboard. Never commit these secrets or put them in HTML.
- `ALLOWED_ORIGINS` should be the exact public URL of the BAZABYOSE Static Site.

## Endpoints
- `GET /health`
- `POST /api/media/sign` with Firebase ID token and JSON `{ "resourceType": "image" }` or `video`.
- `POST /api/admin/transactions/process` admin only: `{ "transactionId": "...", "decision": "approve" }`.
- `POST /api/admin/users/status` admin only: `{ "userId": "...", "status": "blocked" }`.
- `POST /api/admin/users/role` admin only: `{ "userId": "...", "role": "admin" }`.

## Important
This is the backend foundation, not yet connected to the current `index.html`. The current HTML still reads Firestore directly and uses Firebase Functions for some admin actions. We must update the frontend to call these Render routes and test Firestore Security Rules before production. No payment provider API is connected by this starter backend.

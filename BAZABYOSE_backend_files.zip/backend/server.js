const express = require("express");
const cors = require("cors");
const admin = require("firebase-admin");
const cloudinary = require("cloudinary").v2;
require("dotenv").config();

const app = express();
app.use(express.json({ limit: "1mb" }));

const allowedOrigins = (process.env.ALLOWED_ORIGINS || "").split(",").map(x => x.trim()).filter(Boolean);
app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("Origin not allowed by CORS"));
  },
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));

// Credentials stay in Render environment variables, never in browser code or GitHub.
if (!admin.apps.length) {
  if (process.env.FIREBASE_SERVICE_ACCOUNT_BASE64) {
    const account = JSON.parse(Buffer.from(process.env.FIREBASE_SERVICE_ACCOUNT_BASE64, "base64").toString("utf8"));
    admin.initializeApp({ credential: admin.credential.cert(account), projectId: process.env.FIREBASE_PROJECT_ID || account.project_id });
  } else {
    admin.initializeApp({ credential: admin.credential.applicationDefault(), projectId: process.env.FIREBASE_PROJECT_ID });
  }
}
const db = admin.firestore();
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true
});

function requireEnv(names) {
  const missing = names.filter(n => !process.env[n]);
  if (missing.length) throw new Error("Missing environment variables: " + missing.join(", "));
}
async function authenticate(req, res, next) {
  try {
    const h = req.headers.authorization || "";
    if (!h.startsWith("Bearer ")) return res.status(401).json({ error: "Missing Firebase ID token." });
    req.user = await admin.auth().verifyIdToken(h.slice(7));
    next();
  } catch (_) { res.status(401).json({ error: "Invalid or expired login token." }); }
}
async function requireAdmin(req, res, next) {
  try {
    const snap = await db.collection("users").doc(req.user.uid).get();
    if (!snap.exists || snap.data().role !== "admin" || snap.data().status === "blocked")
      return res.status(403).json({ error: "Admin permission required." });
    next();
  } catch (_) { res.status(500).json({ error: "Could not verify admin permissions." }); }
}

app.get("/", (_req, res) => res.json({ service: "BAZABYOSE API", status: "ok" }));
app.get("/health", (_req, res) => res.json({ status: "ok", service: "bazabyose-api" }));

// Signed Cloudinary uploads: the API secret is never sent to the browser.
app.post("/api/media/sign", authenticate, (req, res) => {
  try {
    requireEnv(["CLOUDINARY_CLOUD_NAME", "CLOUDINARY_API_KEY", "CLOUDINARY_API_SECRET"]);
    const resourceType = req.body.resourceType === "video" ? "video" : "image";
    const timestamp = Math.floor(Date.now() / 1000);
    const folder = "bazabyose/public";
    const signature = cloudinary.utils.api_sign_request({ folder, timestamp }, process.env.CLOUDINARY_API_SECRET);
    res.json({ cloudName: process.env.CLOUDINARY_CLOUD_NAME, apiKey: process.env.CLOUDINARY_API_KEY, timestamp, folder, signature, resourceType });
  } catch (e) { res.status(500).json({ error: e.message || "Could not sign upload." }); }
});

// Admin transaction processing: atomic, checks pending status, and prevents duplicate credit/debit.
app.post("/api/admin/transactions/process", authenticate, requireAdmin, async (req, res) => {
  const { transactionId, decision } = req.body || {};
  if (!transactionId || !["approve", "reject"].includes(decision))
    return res.status(400).json({ error: "transactionId and valid decision are required." });
  try {
    const txRef = db.collection("transactions").doc(String(transactionId));
    const result = await db.runTransaction(async t => {
      const txSnap = await t.get(txRef);
      if (!txSnap.exists) throw new Error("TRANSACTION_NOT_FOUND");
      const tx = txSnap.data();
      if (tx.status !== "pending") throw new Error("TRANSACTION_ALREADY_PROCESSED");
      const userRef = db.collection("users").doc(tx.userId);
      const userSnap = await t.get(userRef);
      if (!userSnap.exists) throw new Error("USER_NOT_FOUND");
      const amount = Number(tx.amount);
      if (!Number.isFinite(amount) || amount <= 0) throw new Error("INVALID_AMOUNT");
      if (decision === "approve") {
        const balance = Number(userSnap.data().balance || 0);
        if (tx.type === "deposit") t.update(userRef, { balance: balance + amount, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
        else if (tx.type === "cashout") {
          if (balance < amount) throw new Error("INSUFFICIENT_BALANCE");
          t.update(userRef, { balance: balance - amount, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
        } else throw new Error("UNSUPPORTED_TRANSACTION_TYPE");
      }
      t.update(txRef, { status: decision === "approve" ? "approved" : "rejected", processedAt: admin.firestore.FieldValue.serverTimestamp(), processedBy: req.user.uid });
      t.set(db.collection("auditLogs").doc(), {
        userId: req.user.uid, action: decision === "approve" ? "TRANSACTION_APPROVED" : "TRANSACTION_REJECTED",
        details: `${tx.type} ${amount} RWF; transaction ${transactionId}`, status: "completed",
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
      return { transactionId, status: decision === "approve" ? "approved" : "rejected" };
    });
    res.json({ ok: true, ...result });
  } catch (e) {
    const codes = { TRANSACTION_NOT_FOUND:404, TRANSACTION_ALREADY_PROCESSED:409, USER_NOT_FOUND:404, INVALID_AMOUNT:400, INSUFFICIENT_BALANCE:400, UNSUPPORTED_TRANSACTION_TYPE:400 };
    res.status(codes[e.message] || 500).json({ error: codes[e.message] ? e.message : "Transaction processing failed." });
  }
});

app.post("/api/admin/users/status", authenticate, requireAdmin, async (req, res) => {
  const { userId, status } = req.body || {};
  if (!userId || !["active", "blocked"].includes(status)) return res.status(400).json({ error: "Invalid userId or status." });
  if (userId === req.user.uid) return res.status(400).json({ error: "You cannot block your own admin account." });
  await db.collection("users").doc(userId).update({ status, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  res.json({ ok: true, userId, status });
});
app.post("/api/admin/users/role", authenticate, requireAdmin, async (req, res) => {
  const { userId, role } = req.body || {};
  if (!userId || !["user", "worker", "employer", "broker", "admin"].includes(role))
    return res.status(400).json({ error: "Invalid userId or role." });
  if (userId === req.user.uid && role !== "admin") return res.status(400).json({ error: "You cannot remove your own admin role." });
  await db.collection("users").doc(userId).update({ role, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  res.json({ ok: true, userId, role });
});

const port = Number(process.env.PORT || 10000);
app.listen(port, () => console.log(`BAZABYOSE API listening on ${port}`));
